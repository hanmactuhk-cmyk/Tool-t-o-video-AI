@echo off
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
 echo Can cai Node.js LTS tu https://nodejs.org truoc.
 pause
 exit /b 1
)
if not exist "node_modules\ws\package.json" (
 call npm ci --omit=dev --ignore-scripts
 if errorlevel 1 (
  echo Khong cai duoc thu vien. Kiem tra ket noi internet.
  pause
  exit /b 1
 )
)
start "HNStudio Flow AI" cmd /k node server.cjs
timeout /t 2 /nobreak >nul
start "" http://127.0.0.1:17842
