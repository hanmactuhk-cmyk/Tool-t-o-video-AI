function plan(data){
 const prompts=String(data.prompts||'').split(data.split==='paragraph'?/\r?\n\s*\r?\n/:/\r?\n/).map(x=>x.trim()).filter(Boolean);
 if(!prompts.length)throw Error('Nhập ít nhất một prompt');const starts=data.starts||[],ends=data.ends||[],refs=data.references||[];const mode=data.refmode||'text';let pairs=[];
 if(data.kind==='video'&&data.model.includes('Omni')&&(ends.length||mode==='frames'&&data.pairing!=='default'))throw Error('Omni không dùng ảnh cuối. Chọn ảnh thành phần hoặc chỉ ảnh đầu.');
 if(data.kind==='video'&&data.duration==='10'&&!data.model.includes('Omni'))throw Error('Video 10 giây: chọn Omni Flash');
 if(data.kind==='video'&&data.model.includes('Quality')&&(data.tab==='ingredients'||data.tab==='storyboard'))throw Error('Quality không được dùng trong tab thành phần/nối cảnh của cấu hình này');
 if(mode==='frames'){
  if(data.pairing==='one-many'){if(starts.length!==1||!ends.length)throw Error('Cần đúng 1 ảnh đầu và ít nhất 1 ảnh cuối');pairs=ends.map(e=>[starts[0],e]);}
  else if(data.pairing==='many-one'){if(ends.length!==1||!starts.length)throw Error('Cần đúng 1 ảnh cuối và ít nhất 1 ảnh đầu');pairs=starts.map(s=>[s,ends[0]]);}
  else if(['chain','pairs'].includes(data.pairing)){if(refs.length<2)throw Error('Chọn ít nhất 2 ảnh tham chiếu theo thứ tự');if(data.pairing==='pairs'&&refs.length%2)throw Error('Ghép cặp đôi cần số ảnh chẵn');for(let i=0;i<refs.length-1;i+=data.pairing==='chain'?1:2)pairs.push([refs[i],refs[i+1]]);}
  else{if(starts.length>1&&ends.length>1&&starts.length!==ends.length)throw Error('Số ảnh đầu/cuối cần bằng nhau cho ghép 1:1');const n=Math.max(starts.length,ends.length,1);for(let i=0;i<n;i++)pairs.push([starts[starts.length===1?0:i]||null,ends[ends.length===1?0:i]||null]);}
 }else pairs=[[null,null]];
 const count=Math.max(prompts.length,pairs.length);if(!data.samePrompt&&pairs.length>1&&prompts.length!==pairs.length)throw Error('Nhập một prompt cho mỗi cặp ảnh hoặc chọn dùng prompt đầu cho tất cả');
 const copies=Number(data.copies||1);if(!Number.isInteger(copies)||copies<1||copies>4)throw Error('Số kết quả: 1–4');if(data.tab==='storyboard'&&copies!==1)throw Error('Nối cảnh chỉ tạo 1 video mỗi prompt');
 if(['storyboard','sequential'].includes(data.tab)&&copies!==1)throw Error('Chạy tuần tự chỉ dùng 1 kết quả mỗi prompt');if(data.seed&&!/^[1-9]\d{5}$/.test(String(data.seed)))throw Error('Seed cần 6 chữ số từ 100000 đến 999999');if(!Number.isFinite(Number(data.delay))||data.delay<1||data.delay>300)throw Error('Độ trễ từ 1 đến 300 giây');const max=data.provider==='chatgpt'?5:10;if(refs.length>max)throw Error('Tối đa '+max+' ảnh tham chiếu mỗi dòng');
 const jobs=[];for(let i=0;i<count;i++){const pair=pairs[pairs.length===1?0:i]||[null,null];for(let k=0;k<copies;k++)jobs.push({...data,prompts:data.samePrompt?prompts[0]:prompts[i%prompts.length],startImage:pair[0],endImage:pair[1],references:mode==='ingredients'?(['keywords','exact'].includes(data.tab)?matchRefs(prompts[i%prompts.length],refs,data.tab):data.tab==='sequential'&&i>0?[]:refs):[],copy:k+1});}if(jobs.length>500)throw Error('Tối đa 500 tác vụ mỗi lượt');return jobs;
}
function matchRefs(prompt,refs,mode){const text=prompt.toLocaleLowerCase();return refs.filter(r=>{const name=r.name.replace(/\.[^.]+$/,'').toLocaleLowerCase();if(mode==='exact'){return text.split(/[^\p{L}\p{N}_-]+/u).includes(name);}return [name,...name.split('_').filter(x=>x.length>=3)].some(k=>text.includes(k));});}
module.exports={plan,matchRefs};
