@echo off
cd /d "%~dp0"
call npm ci
if errorlevel 1 goto fail
call npm test
if errorlevel 1 goto fail
call npm run dist
if errorlevel 1 goto fail
explorer dist
pause
exit /b 0
:fail
 echo Build that bai. Giu cua so nay de doc loi.
 pause
 exit /b 1
