const flowPattern = /^https:\/\/(?:flow\.google\.com\/|labs\.google\/fx\/tools\/flow\/)/i;
let ticking = false;
let openedProject = new Set();
const recentLogs = new Map();

async function config(){return (await chrome.storage.local.get('hnstudio')).hnstudio;}
async function request(route,body){
  const c=await config();
  if(!c?.endpoint||!c?.key)throw new Error('Extension chưa được ghép nối với HNStudio. Mở Chrome bằng nút trong ứng dụng.');
  const res=await fetch(c.endpoint+route,{method:body?'POST':'GET',headers:{Authorization:'Bearer '+c.key,...(body?{'Content-Type':'application/json'}:{})},body:body?JSON.stringify(body):undefined,cache:'no-store'});
  const data=await res.json().catch(()=>({}));
  if(!res.ok)throw new Error(data.error||`Ứng dụng HNStudio trả HTTP ${res.status}`);
  return data;
}
async function log(level,message,jobId){
  const k=(jobId||'')+':'+message,now=Date.now();
  if(now-(recentLogs.get(k)||0)<30000)return;
  recentLogs.set(k,now);
  try{await request('/bridge/log',{level,message,jobId});}catch{}
}
async function tabForFlow(preferred){
  const tabs=await chrome.tabs.query({});
  const matches=tabs.filter(t=>t.id&&flowPattern.test(t.url||''));
  if(preferred&&matches.some(t=>t.id===preferred))return matches.find(t=>t.id===preferred);
  const active=matches.find(t=>t.active);
  return active||matches[0]||null;
}
async function evaluate(tabId,expression){
  await chrome.debugger.attach({tabId},'1.3');
  try{
    const result=await chrome.debugger.sendCommand({tabId},'Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true});
    if(result.exceptionDetails)throw new Error(result.exceptionDetails.text||'Flow báo lỗi khi chạy thao tác');
    return result.result?.value;
  }finally{try{await chrome.debugger.detach({tabId});}catch{}}
}
async function submitFiles(tabId,uploads){
  for(const upload of uploads||[]){
    const doc=await chrome.debugger.sendCommand({tabId},'DOM.getDocument');
    const found=await chrome.debugger.sendCommand({tabId},'DOM.querySelector',{nodeId:doc.root.nodeId,selector:upload.selector});
    if(!found.nodeId)throw new Error('Không tìm thấy ô tải ảnh Flow để gắn tệp.');
    await chrome.debugger.sendCommand({tabId},'DOM.setFileInputFiles',{nodeId:found.nodeId,files:upload.files});
  }
}
async function processJob(tab,packet){
  const {job,automation}=packet;
  try{
    await chrome.debugger.attach({tabId:tab.id},'1.3');
    let configResult={ok:true};
    if(job.provider!=='chatgpt'){
      const c=await chrome.debugger.sendCommand({tabId:tab.id},'Runtime.evaluate',{expression:automation.configure,returnByValue:true,awaitPromise:true});
      if(c.exceptionDetails)throw new Error(c.exceptionDetails.text||'Không chọn được cấu hình Flow');
      configResult=c.result?.value||{ok:false,note:'Flow chưa trả cấu hình'};
    }
    const p=await chrome.debugger.sendCommand({tabId:tab.id},'Runtime.evaluate',{expression:automation.prepare,returnByValue:true,awaitPromise:true});
    if(p.exceptionDetails)throw new Error(p.exceptionDetails.text||'Không điền được prompt');
    const prepared=p.result?.value;
    if(!prepared?.ok)throw new Error(prepared?.note||'Flow chưa nhận prompt');
    if(prepared.uploads?.length){
      const staged=await request('/bridge/stage',{jobId:job.id,uploads:prepared.uploads});
      await submitFiles(tab.id,staged.uploads);
    }
    const configNote=configResult.ok?'Đã chọn model và cấu hình trên Flow. ':'Chưa xác minh đủ cấu hình ('+(configResult.note||'mở phần model/cấu hình trên Flow')+'). ';
    const uploadNote=prepared.needsManual?'Một số ảnh chưa khớp ô tải của Flow; cần kiểm tra ảnh trên trang.':prepared.uploads?.length?'Đã đưa ảnh tham chiếu lên Flow.':'Không có ảnh tham chiếu.';
    await request('/bridge/event',{jobId:job.id,status:'prepared',note:configNote+'Đã điền prompt. '+uploadNote+(job.auto&&configResult.ok&&!prepared.needsManual?'':' Chưa bấm Tạo.')});
    if(job.auto&&configResult.ok&&!prepared.needsManual){
      const sent=await chrome.debugger.sendCommand({tabId:tab.id},'Runtime.evaluate',{expression:automation.submit,returnByValue:true,awaitPromise:true});
      const outcome=sent.result?.value;
      if(outcome?.clicked)await request('/bridge/event',{jobId:job.id,status:'submitted',note:'HNStudio đã yêu cầu extension bấm Tạo trên Flow.'});
      else await log('warn',outcome?.note||'Chưa gửi tác vụ; kiểm tra Flow.',job.id);
    }
  }catch(e){
    await log('error','Extension không hoàn tất bước Flow: '+e.message,job.id);
    try{await request('/bridge/event',{jobId:job.id,status:'error',note:e.message});}catch{}
  }finally{try{await chrome.debugger.detach({tabId:tab.id});}catch{}}
}
async function tick(preferredTab){
  if(ticking)return;
  ticking=true;
  try{
    const c=await config();if(!c?.endpoint||!c?.key)return;
    const tab=await tabForFlow(preferredTab);if(!tab)return;
    const inspect=await request('/bridge/inspect');
    let identity;
    try{identity=await evaluate(tab.id,inspect.accountExpression);}catch(e){await log('warn','Chưa đọc được tài khoản Flow: '+e.message);return;}
    await request('/bridge/identity',{email:identity?.email||null,loggedIn:!!identity?.loggedIn,credits:identity?.credits??null,url:tab.url});
    if(identity?.credits!=null&&inspect.closeAccountMenuExpression)await evaluate(tab.id,inspect.closeAccountMenuExpression).catch(()=>{});
    else if(identity?.loggedIn&&inspect.openAccountMenuExpression){const menu=await evaluate(tab.id,inspect.openAccountMenuExpression).catch(()=>null);if(menu?.opened)await log('info','Đang mở menu tài khoản Flow để đọc credits.');}
    const detection=await evaluate(tab.id,inspect.detectExpression);
    if(!detection?.ready){
      if(identity?.loggedIn&&!openedProject.has(tab.id)&&inspect.openProjectExpression){
        const opened=await evaluate(tab.id,inspect.openProjectExpression);
        if(opened?.clicked){openedProject.add(tab.id);await log('info','Đã yêu cầu mở dự án Flow mới.');return;}
      }
      await log('warn',detection?.note||'Flow chưa sẵn sàng; hãy đăng nhập và mở trang dự án.');
      return;
    }
    openedProject.delete(tab.id);
    const packet=await request('/bridge/poll?session='+encodeURIComponent(c.session||'profile'));
    if(packet?.job)await processJob(tab,packet);
  }catch(e){await log('error','Kết nối extension ↔ HNStudio: '+e.message);}
  finally{ticking=false;}
}
chrome.runtime.onMessage.addListener((message,sender)=>{
  if(message?.type==='FLOW_TAB_TICK')tick(sender.tab?.id).catch(()=>{});
});
chrome.tabs.onRemoved.addListener(tabId=>openedProject.delete(tabId));
