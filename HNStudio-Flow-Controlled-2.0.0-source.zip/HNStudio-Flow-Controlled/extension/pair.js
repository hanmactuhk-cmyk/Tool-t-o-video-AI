(async()=>{
  const status=document.getElementById('status');
  try{
    const params=new URLSearchParams(location.hash.slice(1));
    const endpoint=params.get('endpoint'),key=params.get('key');
    if(!endpoint||!key)throw new Error('Thiếu thông tin kết nối do HNStudio cấp. Hãy mở Chrome bằng nút trong HNStudio.');
    const url=new URL(endpoint);
    if(url.protocol!=='http:'||!['127.0.0.1','localhost'].includes(url.hostname))throw new Error('Chỉ cho phép kết nối tới HNStudio trên máy này.');
    await chrome.storage.local.set({hnstudio:{endpoint:url.origin,key,session:crypto.randomUUID()}});
    status.textContent='Đã kết nối. Đang mở Google Flow…';
    setTimeout(()=>location.replace('https://flow.google.com/'),500);
  }catch(e){status.textContent='Không kết nối được: '+e.message;status.style.color='#fca5a5';}
})();
