// The desktop app owns the queue; this page script only wakes the extension worker.
let tickBusy=false;
const tick=()=>{
  if(tickBusy)return;
  tickBusy=true;
  chrome.runtime.sendMessage({type:'FLOW_TAB_TICK',url:location.href}).catch(()=>{}).finally(()=>{tickBusy=false;});
};
tick();
setInterval(tick,2500);
