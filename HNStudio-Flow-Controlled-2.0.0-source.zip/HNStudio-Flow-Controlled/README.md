# HNStudio Flow Controller 2.0.0

Ứng dụng desktop chạy hàng chờ tạo ảnh/video bằng Google Flow. HNStudio là bộ điều khiển; extension được nạp vào hồ sơ Chrome riêng của từng tài khoản và nhận lệnh qua máy local.

## Cách chạy bản mã nguồn

Yêu cầu Node.js 22.12 trở lên, npm và Google Chrome.

```sh
npm install
npm run desktop
```

Trong ứng dụng, thêm hồ sơ Google Flow rồi bấm **Đăng nhập / mở Chrome**. HNStudio tạo hồ sơ Chrome riêng, nạp extension kèm ứng dụng và mở trang ghép nối local. Đăng nhập Google thủ công trong cửa sổ đó. Khi tài khoản đã đăng nhập, extension gửi nhận diện tài khoản và trạng thái credits về HNStudio.

Thêm prompt/ảnh tham chiếu, chọn model và đưa vào hàng chờ. HNStudio giao tác vụ cho extension để thao tác trên tab Flow. Chế độ tự gửi chỉ bấm Tạo sau khi bộ chọn cấu hình nhận diện đúng model, tỷ lệ, thời lượng và chất lượng. Kết quả hiện cần tải từ Flow và gắn vào hàng chờ để xác nhận; extension chưa tự tải và lưu kết quả đầu ra.

## Hồ sơ và dữ liệu

Mỗi tài khoản Flow dùng một thư mục Chrome riêng dưới thư mục dữ liệu ứng dụng. Extension chỉ kết nối tới server localhost của HNStudio. Mật khẩu Google không đi qua HNStudio. Đóng Chrome thì tác vụ mới không được gửi; trạng thái đăng nhập và credits gần nhất vẫn được lưu để hiển thị.

## Giới hạn cần biết

Flow có thể đổi giao diện, tên model, bộ chọn, cách hiển thị credits hoặc quy tắc tải ảnh. Nếu extension không nhận diện chắc chắn được thành phần, tác vụ dừng ở bước đó và ghi log thay vì tự bấm mù. Tạo thật trên Google Flow chưa được kiểm chứng trong môi trường phát triển này; cần chạy thử với một tài khoản và prompt không nhạy cảm trước khi bật hàng loạt.
